package com.agriconnect.Generate.Agreement.App.model;

import lombok.Data;

@Data
public class DeliveryTerms {
    private String date;
    private String location;
    private String transportation;
    private String packaging;
}
