package com.agriconnect.Generate.Agreement.App.model;

import lombok.Data;

@Data
public class TermCondition {
    private String tId;
    private String title;
    private String content;
}
