package com.agriconnect.Generate.Agreement.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateAgreementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
